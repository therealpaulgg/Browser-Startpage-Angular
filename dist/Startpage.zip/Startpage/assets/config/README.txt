PLEASE obtain API keys from the following locations:
Weather key: https://openweathermap.org/appid
Yelp key: https://www.yelp.com/fusion
Bing maps key: https://docs.microsoft.com/en-us/bingmaps/getting-started/bing-maps-dev-center-help/getting-a-bing-maps-key

When you get your API key after setting up your account,
change the kes in key.json to what you need.

The reason you need your own API key is because these APIs have limited amounts of API calls that can be performed in a time period. These API keys are for individual use only.

I know the following two search engines work (use these URLS):
https://duckduckgo.com
https://google.com/search
