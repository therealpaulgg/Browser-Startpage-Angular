PLEASE Obtain an API key from OpenWeatherMap at https://openweathermap.org/appid. When you get your API key after setting up your account, 
change the key in key.json to what you need. 

The reason you need your own API key is because the OpenWeatherMap has a limited amount of API calls that can be performed in a time period, and I 
do not want to get my API key banned. 

I know the following two search engines work (use these URLS):
https://duckduckgo.com
https://google.com/search